package codedevl;

public class MonHoc {
	private String mamon, tenmon;
	private int sotc;
	public MonHoc(String mamon, String tenmon, int sotc) {
		super();
		this.mamon = mamon;
		this.tenmon = tenmon;
		this.sotc = sotc;
	}
	public String getMamon() {
		return mamon;
	}
	public String getTenmon() {
		return tenmon;
	}
	
}
