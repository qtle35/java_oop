package codedevl;

public class Diemdanh {
	private String maSv, diemdanh;
	private int chuyenCan;
	public Diemdanh(String maSv, String diemdanh) {
		super();
		this.maSv = maSv;
		this.diemdanh = diemdanh;
	}
	public String getMaSv() {
		return maSv;
	}
	public String getDiemdanh() {
		return diemdanh;
	}
	
	
}
