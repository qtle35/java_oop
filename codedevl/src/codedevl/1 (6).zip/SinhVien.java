package codedevl;

public class SinhVien {
	private String maSv, tenSv, lop;
	private Diemdanh diemdanh;
	private int chuyenCan;
	public SinhVien(String maSv, String tenSv, String lop) {
		super();
		this.maSv = maSv;
		this.tenSv = tenSv;
		this.lop = lop;
	}

	public String getMaSv() {
		return maSv;
	}
	
	public void setDiemdanh(Diemdanh diemdanh) {
		this.diemdanh = diemdanh;
		this.chuyenCan = tinhChuyenCan(diemdanh.getDiemdanh());
	}

	public int tinhChuyenCan(String s) {
		int res=10;
		for(int i=0;i<s.length();i++) {
			if(s.charAt(i)=='m') res-=1;
			else if (s.charAt(i)=='v') res-=2;
		}
		if(res<0) return 0;
		return res;
	}
	
	public String getLop() {
		return lop;
	}

	@Override
	public String toString() {
		if(chuyenCan!=0) return maSv + " " + tenSv + " " + lop+" "+chuyenCan;
		return maSv + " " + tenSv + " " + lop+" "+chuyenCan+" KDDK";
	}
	
	
}
