package danhsachsinhvien1;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

class CaThi implements Comparable<CaThi>{
    private String ma;
    private String ngay;
    private String gio;
    private String phong;

    public CaThi(int ma, String ngay, String gio, String phong) {
        this.ma = "C" + String.format("%03d", ma);
        this.ngay = ngay;
        this.gio = gio;
        this.phong = phong;
    }
    
    @Override
    public String toString(){
        return ma + " " + ngay + " " + gio + " " + phong;
    }
    
    @Override
    public int compareTo(CaThi o){
        if(this.ngay.compareTo(o.ngay) < 0) return -1;
        else if(this.ngay.compareTo(o.ngay) > 0) return 1;
        else return this.gio.compareTo(o.gio);
    }
   
}
